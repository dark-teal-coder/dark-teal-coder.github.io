import argparse
import base64
import json
import logging
import re
import threading
import webbrowser
from datetime import date, datetime
from pathlib import Path

import pymupdf
from flask import Flask, Response, jsonify, render_template, request
from waitress import serve

from dhocr.excel_handler import append_to_excel
from dhocr import plugin_runner

CONFIG_DIR = Path("config")
_config_path: Path = CONFIG_DIR / "global_config.json"

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

logger = logging.getLogger(__name__)


# ── helpers ───────────────────────────────────────────────────────────────────

def _load_config(path: Path) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _load_records(log_file: str, start: date | None, end: date | None) -> list[dict]:
    path = Path(log_file)
    if not path.exists():
        return []
    records = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    records.reverse()
    if start and end:
        records = [r for r in records
                   if start <= datetime.fromisoformat(r["timestamp"]).date() <= end]
    return records


# ── routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("review.html")


def _cfg_and_records(config_path: Path, start_str: str | None, end_str: str | None):
    cfg = _load_config(config_path)
    log_file = cfg.get("process_log_file", "")
    forms_config_dir = cfg.get("forms_config_dir", "config/forms")
    start = date.fromisoformat(start_str) if start_str else None
    end = date.fromisoformat(end_str) if end_str else None
    records = _load_records(log_file, start, end)
    return cfg, forms_config_dir, records


@app.route("/api/form_ids")
def api_form_ids():
    try:
        _, forms_config_dir, records = _cfg_and_records(
            _config_path,
            request.args.get("start_date"),
            request.args.get("end_date"),
        )
    except Exception:
        logger.warning("Failed to load config/records for /api/form_ids", exc_info=True)
        return jsonify({"form_ids": [], "forms_config_dir": "config/forms"})

    ids = sorted({
        inst.get("form_id")
        for r in records
        for inst in r.get("instances", [])
        if inst.get("form_id")
    })
    return jsonify({"form_ids": ids, "forms_config_dir": forms_config_dir})


@app.route("/api/splits")
def api_splits():
    form_id = request.args.get("form_id", "")
    try:
        _, _, records = _cfg_and_records(
            _config_path,
            request.args.get("start_date"),
            request.args.get("end_date"),
        )
    except Exception:
        logger.warning("Failed to load config/records for /api/splits", exc_info=True)
        return jsonify({"splits": []})

    # records are newest-first; first occurrence of each json path is the latest
    seen: dict[str, dict] = {}
    for record in records:
        ts = record["timestamp"]
        for inst in record.get("instances", []):
            if inst.get("form_id") != form_id:
                continue
            jp = inst.get("json", "")
            if jp and jp not in seen:
                seen[jp] = {**inst, "timestamp": ts}
    return jsonify({"splits": list(seen.values())})


@app.route("/api/pdf_pages")
def api_pdf_pages():
    json_file = request.args.get("json_file", "")
    if not json_file:
        return jsonify([])
    json_path = Path(json_file)
    if not json_path.exists():
        return jsonify([])
    m = re.match(r"(.+)_p(\d+)-(\d+)_.+\.json$", json_path.name)
    if not m:
        return jsonify([])
    pdf_stem, start_page, end_page = m.group(1), int(m.group(2)), int(m.group(3))
    pdf_path = json_path.parent / "ORIGINAL_PDFs" / f"{pdf_stem}.pdf"
    if not pdf_path.exists():
        return jsonify([])
    images = []
    doc = pymupdf.open(str(pdf_path))
    try:
        for i in range(start_page - 1, end_page):
            if i < len(doc):
                pix = doc[i].get_pixmap(dpi=150)
                images.append(base64.b64encode(pix.tobytes("png")).decode())
    finally:
        doc.close()
    return jsonify(images)


@app.route("/api/instance")
def api_instance():
    json_file = request.args.get("json_file", "")
    form_id = request.args.get("form_id", "")
    forms_config_dir = request.args.get("forms_config_dir", "config/forms")

    json_data = None
    if json_file and Path(json_file).exists():
        with open(json_file, encoding="utf-8") as f:
            json_data = json.load(f)

    schema: list[dict] = []
    if form_id:
        cfg_path = Path(forms_config_dir) / f"{form_id}.json"
        if cfg_path.exists():
            with open(cfg_path, encoding="utf-8") as f:
                form_cfg = json.load(f)
            for pg in form_cfg.get("pages", []):
                schema.extend(pg.get("schema", []))

    return Response(
        json.dumps({"json_data": json_data, "schema": schema}, ensure_ascii=False),
        mimetype="application/json",
    )


@app.route("/api/save", methods=["POST"])
def api_save():
    body = request.get_json(force=True)
    json_file = body.get("json_file", "")
    data = body.get("data")
    form_id = body.get("form_id", "")
    forms_config_dir = body.get("forms_config_dir", "config/forms")

    if not json_file or data is None:
        return jsonify({"error": "missing json_file or data"}), 400

    with open(json_file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    excel_error = None
    if form_id:
        try:
            cfg_path = Path(forms_config_dir) / f"{form_id}.json"
            with open(cfg_path, encoding="utf-8") as f:
                form_cfg = json.load(f)
            excel_path = form_cfg.get("excel_file")
            if excel_path:
                append_to_excel(data, Path(excel_path), json_file)
            else:
                excel_error = f"No excel_file configured for form '{form_id}'"
            plugin_update = form_cfg.get("plugin_update_record")
            if plugin_update:
                plugin_runner.run_plugin(plugin_update, {"<json>": str(Path(json_file).resolve())})
        except PermissionError as exc:
            logger.warning("Excel file locked for %s: %s", json_file, exc, exc_info=True)
            excel_error = "Excel file is open in another program. Please close it and try again."
        except Exception as exc:
            logger.warning("Excel update failed for %s: %s", json_file, exc, exc_info=True)
            excel_error = str(exc)

    return jsonify({"ok": True, "excel_error": excel_error})


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    global _config_path
    parser = argparse.ArgumentParser(description="OCR-LLM review web app.")
    parser.add_argument(
        "--config",
        type=Path,
        default=CONFIG_DIR / "global_config.json",
        help="Path to global config JSON (default: config/global_config.json)",
    )
    args = parser.parse_args()
    _config_path = args.config
    threading.Timer(1.0, lambda: webbrowser.open("http://localhost:5187")).start()
    serve(app, host="127.0.0.1", port=5187)


if __name__ == "__main__":
    main()
