import base64
import json
import logging
from pathlib import Path
from typing import Any, cast
import httpx

from openai import OpenAI
from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam

logger = logging.getLogger(__name__)


def _encode_image(image_path: Path) -> str:
    """Return a base64-encoded PNG data URL for the image."""
    with open(image_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def extract_page(image_path: str | Path, page_config: dict, llm_config: dict) -> dict:
    """Call the visual LLM to extract structured data from one form page.

    Args:
        image_path: Path to the PNG image of the page.
        page_config: Dict with at least "prompt" and "schema" keys.
        llm_config: Dict with "endpoint", "model", and "api_key" keys.

    Returns:
        Parsed JSON dict from the LLM response.
    """
    image_path = Path(image_path)
    timeout = llm_config.get("timeout", 60)
    extra_params = llm_config.get("params", {})

    image_url = _encode_image(image_path)
    sys_prompt = llm_config["sys_prompt"]
    user_prompt = page_config.get("prompt") or llm_config["default_user_prompt"]
    schema = page_config.get("schema")

    user_content: list[Any] = [
        {"type": "image_url", "image_url": {"url": image_url}},
        {"type": "text", "text": user_prompt},
    ]
    if schema:
        user_content.append({"type": "text", "text": f"Schema:\n{json.dumps(schema, ensure_ascii=False, indent=2)}"})

    messages = cast(
        list[ChatCompletionMessageParam],
        [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_content},
        ],
    )

    output_format = page_config.get("output_format", "json")
    model = llm_config["model"]
    logger.debug(
        "LLM request: model=%s output_format=%s image=%s",
        model, output_format, image_path.name,
    )

    create_kwargs: dict[str, Any] = {
        "model": model,
        "messages": messages,
        **extra_params,
    }
    if output_format != "text":
        create_kwargs["response_format"] = {"type": "json_object"}

    with httpx.Client(verify=False) as http_client:
        client = OpenAI(
            api_key=llm_config["api_key"],
            base_url=llm_config["endpoint"],
            timeout=timeout,
            http_client=http_client,
        )
        response = client.chat.completions.create(**create_kwargs)

    content = response.choices[0].message.content
    if content is None:
        raise ValueError("LLM response contains no message content")
    logger.debug("LLM response: %d chars", len(content))

    if output_format == "text":
        return {page_config.get("output_key", "text"): content}
    return json.loads(content)
