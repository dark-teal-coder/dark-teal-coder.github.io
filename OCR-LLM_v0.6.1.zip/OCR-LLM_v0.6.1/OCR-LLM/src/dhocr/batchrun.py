import argparse
import logging
import sys
import os
from pathlib import Path

from openai import APITimeoutError, AuthenticationError, PermissionDeniedError, RateLimitError

from dhocr import config_loader, form_processor

_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"

os.environ["NO_PROXY"] = ".dh.hksarg"

_ANSI_RESET = "\033[0m"
_LEVEL_COLORS = {
    logging.WARNING: "\033[33m",    # yellow
    logging.ERROR: "\033[31m",      # red
    logging.CRITICAL: "\033[1;31m", # bold red
}


class _ColorFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        msg = super().format(record)
        color = _LEVEL_COLORS.get(record.levelno)
        return f"{color}{msg}{_ANSI_RESET}" if color else msg


_console_handler = logging.StreamHandler(sys.stderr)
_console_handler.setFormatter(_ColorFormatter(_LOG_FORMAT, datefmt=_LOG_DATEFMT))
logging.basicConfig(level=logging.INFO, handlers=[_console_handler])
logger = logging.getLogger(__name__)


def _setup_file_logging(config: dict) -> None:
    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_LOG_DATEFMT)
    root = logging.getLogger()

    log_file = config.get("log_file")
    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        h = logging.FileHandler(log_file, encoding="utf-8")
        h.setLevel(logging.INFO)
        h.setFormatter(formatter)
        root.addHandler(h)

    log_warning_file = config.get("log_warning_file")
    if log_warning_file:
        Path(log_warning_file).parent.mkdir(parents=True, exist_ok=True)
        h = logging.FileHandler(log_warning_file, encoding="utf-8")
        h.setLevel(logging.WARNING)
        h.setFormatter(formatter)
        root.addHandler(h)

DEFAULT_CONFIG_PATH = Path("config/global_config.json")


def main() -> int:
    parser = argparse.ArgumentParser(description="OCR-LLM PDF processing pipeline.")
    parser.add_argument(
        "--config",
        type=Path,
        default=DEFAULT_CONFIG_PATH,
        help=f"Path to global config JSON (default: {DEFAULT_CONFIG_PATH})",
    )
    args = parser.parse_args()

    try:
        config = config_loader.load_global_config(args.config)
    except (FileNotFoundError, ValueError) as exc:
        logger.error("Failed to load global config: %s", exc)
        return 1

    _setup_file_logging(config)
    errors = 0

    folder_modes = [
        (config.get("forms_input_folder"), "no_qr"),
        (config.get("forms_qr_input_folder"), "qr"),
        (config.get("forms_mixed_input_folder"), "mixed"),
    ]

    total_pdfs = 0
    for folder_key, mode in folder_modes:
        if folder_key is None:
            continue
        folder = Path(folder_key)
        if not folder.exists():
            logger.warning("Input folder does not exist, skipping: %s", folder)
            continue
        pdf_files = sorted(folder.rglob("*.pdf"))
        if not pdf_files:
            logger.info("No PDF files found in %s", folder)
            continue
        logger.info("Found %d PDF file(s) in %s (mode=%s).", len(pdf_files), folder, mode)
        total_pdfs += len(pdf_files)
        for pdf_path in pdf_files:
            try:
                success = form_processor.process_pdf(pdf_path, config, mode=mode)
                if not success:
                    errors += 1
            except (AuthenticationError, PermissionDeniedError, APITimeoutError, RateLimitError):
                logger.critical("Aborting batch due to LLM API error.")
                return 1
            except Exception as exc:
                logger.error("Unhandled error processing %s: %s", pdf_path.name, exc, exc_info=True)
                errors += 1

    if total_pdfs == 0:
        logger.info("No PDF files found in any input folder.")
        return 0

    if errors:
        logger.warning("Completed with %d error(s).", errors)
        return 1
    logger.info("All PDFs processed successfully.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
