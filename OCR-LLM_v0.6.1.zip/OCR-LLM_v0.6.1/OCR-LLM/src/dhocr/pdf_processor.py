import logging
import tempfile
from pathlib import Path

import pymupdf

logger = logging.getLogger(__name__)

_A4_WIDTH_IN  = 210 / 25.4   # 8.268 inches
_A4_HEIGHT_IN = 297 / 25.4   # 11.693 inches
_MIN_DPI = 200


def _single_image_dpi(img_info: tuple) -> float:
    """Estimate DPI of a single full-page image assuming A4 page size."""
    pixel_w = img_info[2]
    pixel_h = img_info[3]
    return min(pixel_w / _A4_WIDTH_IN, pixel_h / _A4_HEIGHT_IN)


def _detect_page_dpi(page: pymupdf.Page, images: list, fallback: int) -> int:
    """Return the DPI of the highest-resolution embedded image on *page*.

    DPI is derived from each image's pixel dimensions vs. its rendered size in
    PDF points (1 point = 1/72 inch).  The maximum across all images is returned
    so that the highest-resolution layer (typically the JBIG2 foreground mask)
    sets the render resolution.  Falls back to *fallback* if no rect is available.
    """
    max_dpi = 0.0
    for img_info in images:
        xref    = img_info[0]
        pixel_w = img_info[2]
        pixel_h = img_info[3]
        rects = page.get_image_rects(xref)
        if not rects:
            continue
        rect = rects[0]
        if rect.width > 0 and rect.height > 0:
            dpi_x = pixel_w * 72 / rect.width
            dpi_y = pixel_h * 72 / rect.height
            max_dpi = max(max_dpi, dpi_x, dpi_y)
    return round(max_dpi) if max_dpi > 0 else fallback


def extract_pages(pdf_path: str | Path, temp_dir: str | Path | None = None, dpi: int = 200) -> list[Path]:
    """Extract every page of *pdf_path* as an image file.

    Single-image or Multi-image pages (e.g. scanner MRC layers with background + foreground mask):
    the page is rendered via PyMuPDF, correctly compositing all layers, soft masks,
    and colour spaces.  The render DPI is auto-detected from the highest-resolution
    embedded image on the page; *dpi* is used as a fallback when detection fails.

    Raises ValueError if any page has no embedded raster image or if the
    detected DPI is below the minimum threshold of 180 dpi.
    Returns an ordered list of image paths (one per page).
    """
    pdf_path = Path(pdf_path)
    if temp_dir is None:
        temp_dir = Path(tempfile.mkdtemp(prefix="ocr_llm_"))
    else:
        temp_dir = Path(temp_dir)
        temp_dir.mkdir(parents=True, exist_ok=True)

    image_paths: list[Path] = []
    doc = pymupdf.open(str(pdf_path))
    try:
        for page_index in range(len(doc)):
            page: pymupdf.Page = doc[page_index]
            images = page.get_images(full=True)
            if not images:
                raise ValueError(
                    f"Page {page_index + 1} of {pdf_path.name} has no embedded raster image."
                )


            # Multi-image page (e.g. MRC scanner layers): let MuPDF render the full
            # page so that background, foreground mask, and soft masks are correctly
            # composited — manual image pasting cannot handle PDF blending operations.
            render_dpi = _detect_page_dpi(page, images, fallback=dpi)
            logger.debug(
                "Page %d: %d images, detected %d dpi",
                page_index + 1, len(images), render_dpi,
            )
            if render_dpi < _MIN_DPI * 0.9:
                raise ValueError(
                    f"{pdf_path.name} page {page_index + 1}: detected DPI "
                    f"{render_dpi} is below the minimum {_MIN_DPI} dpi — aborting."
                )
            out_path = temp_dir / f"page_{page_index + 1:04d}.png"
            pix = page.get_pixmap(dpi=render_dpi)
            pix.save(str(out_path))

            image_paths.append(out_path)
    finally:
        doc.close()

    return image_paths
