import copy
import json
import logging
import shutil
from datetime import datetime
from pathlib import Path

import yaml

from openai import APITimeoutError, AuthenticationError, PermissionDeniedError, RateLimitError, InternalServerError
from PIL import Image, ImageStat

from . import config_loader, excel_handler, llm_client, output_handler, pdf_processor, plugin_runner, qr_decoder

logger = logging.getLogger(__name__)


_BLANK_PAGE_THRESHOLD = 10.0
_LLM_MAX_RETRIES = 1


def _is_blank(image_path: Path) -> bool:
    """Return True if the page image is blank (stddev of pixel values below threshold)."""
    stat = ImageStat.Stat(Image.open(image_path).convert("L"))
    return stat.stddev[0] < _BLANK_PAGE_THRESHOLD


def _group_pages(page_images: list[Path]) -> list[dict]:
    """Detect form boundaries and group pages into form instances.

    Each item in the returned list is:
        {
            "form_id": str | None,
            "pages": [(page_image_path, page_num_in_form), ...],
        }

    A new instance starts when:
    - The form_id changes from the previous page, OR
    - The page number is already present in the current instance (duplicate or reset).
    Pages without a QR code use form_id=None (→ default config).
    Out-of-order pages within an instance are sorted by page number.
    """
    instances: list[dict] = []
    current: dict | None = None

    for img_path in page_images:
        if _is_blank(img_path):
            continue

        try:
            qr = qr_decoder.decode_qr(img_path)
        except ValueError as exc:
            logger.warning("Skipping page %s: %s", img_path.name, exc)
            continue
        form_id = qr["form_id"] if qr else None
        page_num = int(qr["page"]) if qr else None

        current_page_nums = {p[1] for p in current["pages"]} if current else set()

        start_new = (
            current is None
            or current["form_id"] != form_id
            or (page_num is not None and page_num in current_page_nums)
        )

        if start_new:
            if current is not None:
                current["pages"].sort(key=lambda p: p[1])
            current = {"form_id": form_id, "pages": []}
            instances.append(current)

        assert current is not None
        effective_page_num = page_num if page_num is not None else len(current["pages"]) + 1
        current["pages"].append((img_path, effective_page_num))

    if current is not None:
        current["pages"].sort(key=lambda p: p[1])

    return instances


def _group_pages_no_qr(page_images: list[Path], form_id: str, num_pages: int) -> list[dict]:
    """Group sequential pages into form instances of exactly num_pages pages each."""
    instances = []
    for i in range(0, len(page_images), num_pages):
        chunk = page_images[i:i + num_pages]
        pages = [(img, j + 1) for j, img in enumerate(chunk)]
        instances.append({"form_id": form_id, "pages": pages})
    return instances


def _classify_page_llm(img_path: Path, form_selector: dict, llm_cfg: dict) -> dict | None:
    """Call the LLM to classify a page into a form_id and page_num.

    Returns the parsed JSON dict from the LLM, or None if all attempts fail.
    """
    classifier_llm_cfg = {**llm_cfg, "sys_prompt": form_selector["sys_prompt"]}
    classifier_page_cfg = {"prompt": form_selector["user_prompt"], "output_format": "json"}
    total_attempts = _LLM_MAX_RETRIES + 1
    for attempt in range(1, total_attempts + 1):
        try:
            return llm_client.extract_page(img_path, classifier_page_cfg, classifier_llm_cfg)
        except (AuthenticationError, PermissionDeniedError) as exc:
            logger.error(
                "Classifier LLM authentication/permission error (HTTP %d) for %s",
                exc.status_code, img_path.name,
            )
            raise
        except RateLimitError as exc:
            if attempt < total_attempts:
                logger.warning(
                    "Classifier LLM Too many requests error (HTTP %d) for %s (attempt %d/%d): ; retrying.",
                    exc.status_code, img_path.name, attempt, total_attempts,
                )
                continue
            logger.error(
                "Classifier LLM Too many requests error (HTTP %d) for %s after %d attempts; skipping page.",
                exc.status_code, img_path.name, total_attempts,
            )
            raise
        except (APITimeoutError, InternalServerError) as exc:
            if attempt < total_attempts:
                logger.warning(
                    "Classifier LLM API timeout/Internal Server Error (HTTP %d) for %s (attempt %d/%d); retrying.",
                    exc.status_code, img_path.name, attempt, total_attempts,
                )
            else:
                logger.warning(
                    "Classifier LLM API timeout/Internal Server Error (HTTP %d) for %s after %d attempts: %s; skipping page.",
                    exc.status_code, img_path.name, total_attempts,
                )
        except Exception as exc:
            if attempt < total_attempts:
                logger.warning(
                    "Classifier LLM failed for %s (attempt %d/%d): %s; retrying.",
                    img_path.name, attempt, total_attempts, exc,
                )
            else:
                logger.warning(
                    "Classifier LLM failed for %s after %d attempts: %s; skipping page.",
                    img_path.name, total_attempts, exc, exc_info=True,
                )
    return None


def _group_pages_mixed(
    page_images: list[Path],
    form_selector: dict,
    llm_cfg: dict,
    forms_dir: Path,
) -> list[dict]:
    """Group pages using LLM-based form classification (mixed-form PDFs).

    The LLM is called only for the first page of each new form instance to
    determine the form_id. Subsequent pages are assigned sequential page numbers
    using num_pages from the form config. num_pages is required; its absence
    raises ValueError and aborts the PDF.
    """
    instances: list[dict] = []
    current: dict | None = None
    remaining = 0       # pages left in current instance before next LLM call
    page_num_in_form = 0

    for img_path in page_images:
        if _is_blank(img_path):
            continue

        if remaining > 0:
            page_num_in_form += 1
            remaining -= 1
        else:
            result = _classify_page_llm(img_path, form_selector, llm_cfg)
            if result is None:
                logger.error(
                    "Classifier returned no result for %s; page will be excluded.",
                    img_path.name,
                )
                continue

            form_id = result.get("form_id") or None
            if form_id is None:
                logger.error(
                    "Classifier returned form_id=null for %s; page will be excluded.",
                    img_path.name,
                )
                continue

            logger.info(
                "Page %d classified as form type: %s",
                int(img_path.stem[5:]), form_id,
            )

            try:
                form_cfg = config_loader.get_form_config(form_id, forms_dir)
            except FileNotFoundError:
                logger.error(
                    "No config found for form_id=%s returned by classifier; aborting PDF.",
                    form_id,
                )
                raise

            num_pages = form_cfg.get("num_pages")
            if not num_pages:
                logger.error(
                    "form_id=%s config missing 'num_pages'; aborting PDF.", form_id,
                )
                raise ValueError(f"form_id={form_id} config missing 'num_pages'")

            remaining = num_pages - 1
            page_num_in_form = 1

            if current is not None:
                current["pages"].sort(key=lambda p: p[1])
            current = {"form_id": form_id, "pages": []}
            instances.append(current)

        assert current is not None
        current["pages"].append((img_path, page_num_in_form))

    if current is not None:
        current["pages"].sort(key=lambda p: p[1])

    return instances


def _write_process_log(log_file: Path, original_pdf: Path, instances: list[dict]) -> None:
    """Append one JSONL record to the process log file."""
    record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "original_pdf": str(original_pdf),
        "instances": instances,
    }
    log_file.parent.mkdir(parents=True, exist_ok=True)
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def process_pdf(pdf_path: str | Path, global_config: dict, mode: str = "qr") -> bool:
    """Return True on full success, False if any error occurred."""
    """Process a single PDF: extract pages, call LLM per form instance, write outputs."""
    pdf_path = Path(pdf_path)
    forms_dir = Path(global_config["forms_config_dir"])
    llm_cfg = global_config["llm"]

    if mode == "no_qr":
        input_root = Path(global_config["forms_input_folder"])
        output_root = Path(global_config["forms_output_folder"])
    elif mode == "mixed":
        input_root = Path(global_config["forms_mixed_input_folder"])
        output_root = Path(global_config["forms_mixed_output_folder"])
    else:
        input_root = Path(global_config["forms_qr_input_folder"])
        output_root = Path(global_config["forms_qr_output_folder"])

    rel_dir = pdf_path.parent.relative_to(input_root)
    output_dir = output_root / rel_dir

    logger.info("Processing PDF: %s", pdf_path)

    temp_base = Path(global_config.get("temp_folder", "temp"))
    temp_dir = temp_base / pdf_path.stem
    temp_dir.mkdir(parents=True, exist_ok=True)
    failed = False
    process_log_instances: list[dict] = []
    try:
        page_images = pdf_processor.extract_pages(
            pdf_path, temp_dir, dpi=global_config.get("render_dpi", 200)
        )

        if mode == "no_qr":
            form_id = pdf_path.relative_to(input_root).parts[0]
            try:
                form_cfg = config_loader.get_form_config(form_id, forms_dir)
            except FileNotFoundError as exc:
                logger.error("Skipping PDF (no config): %s", exc)
                return False
            num_pages = form_cfg.get("num_pages")
            if not num_pages:
                logger.error("form_id=%s config missing 'num_pages'; cannot group pages.", form_id)
                return False
            instances = _group_pages_no_qr(page_images, form_id, num_pages)
        elif mode == "mixed":
            selector_path = Path(global_config.get("form_selector_file", "config/form_selector.yaml"))
            if not selector_path.exists():
                logger.error("form_selector file not found: %s; aborting PDF.", selector_path)
                return False
            with open(selector_path, encoding="utf-8") as f:
                form_selector = yaml.safe_load(f)
            instances = _group_pages_mixed(page_images, form_selector, llm_cfg, forms_dir)
        else:
            instances = _group_pages(page_images)

        # Track sequence numbers per form_id within this PDF.
        seq_counters: dict[str | None, int] = {}
        process_file_plugins: list[str] = []

        for instance in instances:
            form_id = instance["form_id"]
            pages = instance["pages"]

            seq_counters[form_id] = seq_counters.get(form_id, 0) + 1
            seq = seq_counters[form_id]

            if mode == "no_qr":
                pass  # form_cfg already loaded above
            else:
                try:
                    form_cfg = config_loader.get_form_config(form_id, forms_dir)
                except FileNotFoundError as exc:
                    logger.error("Skipping form instance (no config): %s", exc)
                    failed = True
                    continue

            num_pages = form_cfg.get("num_pages")
            if num_pages:
                found = {p[1] for p in pages}
                missing = sorted(set(range(1, num_pages + 1)) - found)
                if missing:
                    logger.warning(
                        "form_id=%s seq=%d: missing pages %s (found: %s)",
                        form_id, seq, missing, sorted(found),
                    )

            # Build a page_num → page_config lookup.
            page_cfg_by_num: dict[int, dict] = {
                p["page"]: p for p in form_cfg.get("pages", [])
            }

            page_results: list[dict] = []

            min_image_page_num = 9999
            max_image_page_num = 0

            for img_path, page_num in pages:
                page_cfg = page_cfg_by_num.get(page_num)
                image_page_num = int(img_path.stem[5:9])
                min_image_page_num = min(min_image_page_num, image_page_num)
                max_image_page_num = max(max_image_page_num, image_page_num)

                if page_cfg is None:
                    logger.warning(
                        "No page config for form_id=%s page=%d; skipping LLM call.",
                        form_id,
                        page_num,
                    )
                    continue

                # Strip description fields before passing schema to LLM (saves tokens).
                page_cfg_augmented = copy.deepcopy(page_cfg)
                for entry in page_cfg_augmented.get("schema", []):
                    entry.pop("description", None)

                total_attempts = _LLM_MAX_RETRIES + 1
                for attempt in range(1, total_attempts + 1):
                    try:
                        if attempt == 1:
                            logger.info(
                                "Calling LLM for form_id=%s page %d (seq=%d)",
                                form_id, page_num, seq,
                            )
                        else:
                            logger.info(
                                "Retrying LLM for form_id=%s page %d (seq=%d, attempt %d/%d)",
                                form_id, page_num, seq, attempt, total_attempts,
                            )
                        result = llm_client.extract_page(img_path, page_cfg_augmented, llm_cfg)
                        logger.info(
                            "Finish calling LLM for form_id=%s page %d (seq=%d)",
                            form_id, page_num, seq,
                        )
                        page_results.append(result)
                        break
                    except (AuthenticationError, PermissionDeniedError) as exc:
                        logger.error(
                            "LLM authentication/permission error (HTTP %d) for %s page %d",
                            exc.status_code, pdf_path.name, page_num,
                        )
                        raise
                    except RateLimitError as exc:
                        if attempt < total_attempts:
                            logger.warning(
                                "LLM Too many requests error (HTTP %d) for %s page %d ; will retry.",
                                exc.status_code, pdf_path.name, page_num,
                            )
                            continue
                        logger.error(
                            "LLM Too many requests error (HTTP %d) for %s page %d after %d attempts;  aborting PDF.",
                            exc.status_code, pdf_path.name, page_num, total_attempts, 
                        )
                        raise
                    except (APITimeoutError, InternalServerError) as exc:
                        if attempt < total_attempts:
                            logger.warning(
                                "API timeout/Internal Server Error (HTTP %d) for %s page %d: ; will retry.",
                                exc.status_code, pdf_path.name, page_num,
                            )
                            continue
                        logger.error(
                            "API timeout/Internal Server Error (HTTP %d) for %s page %d after %d attempts; aborting PDF.",
                            exc.status_code, pdf_path.name, page_num, total_attempts 
                        )
                        raise
                    except Exception as exc:
                        if attempt < total_attempts:
                            logger.warning(
                                "LLM call failed for %s page %d: %s; will retry.",
                                pdf_path.name, page_num, exc,
                            )
                            continue
                        logger.error(
                            "LLM call failed for %s page %d after %d attempts: %s; aborting PDF.",
                            pdf_path.name, page_num, total_attempts, exc, exc_info=True,
                        )
                        raise

            log_entry: dict = {
                "form_id": form_id,
                "json": None,
            }
            process_log_instances.append(log_entry)

            if not page_results:
                logger.warning("No results for form_id=%s seq=%d; skipping output.", form_id, seq)
                continue

            merged = output_handler.merge_jsons(page_results)

            form_id_str = form_id
            json_filename = f"{pdf_path.stem}_p{min_image_page_num}-{max_image_page_num}_{form_id_str}.json"
            json_path = output_dir / json_filename
            output_handler.write_json(merged, json_path)
            log_entry["json"] = str(json_path)

            excel_path = form_cfg.get("excel_file")
            if excel_path:
                excel_handler.append_to_excel(merged, Path(excel_path), json_path)

            plugin_create = form_cfg.get("plugin_create_record")
            if plugin_create:
                plugin_runner.run_plugin(plugin_create, {"<json>": str(json_path)})

            plugin_process = form_cfg.get("plugin_process_file")
            if plugin_process and plugin_process not in process_file_plugins:
                process_file_plugins.append(plugin_process)

    except (AuthenticationError, PermissionDeniedError, APITimeoutError, RateLimitError):
        raise
    except Exception as exc:
        logger.error("Unexpected error processing %s: %s", pdf_path.name, exc, exc_info=True)
        failed = True
    finally:
        if global_config.get("debug"):
            logger.info("Keeping temp images: %s", temp_dir)
        else:
            shutil.rmtree(temp_dir, ignore_errors=True)

    process_log_file = global_config.get("process_log_file")
    if process_log_file:
        _write_process_log(
            log_file=Path(process_log_file),
            original_pdf=pdf_path,
            instances=process_log_instances,
        )

    if failed:
        logger.warning("PDF left in input folder due to errors: %s", pdf_path.name)
    elif global_config.get("debug"):
        dest_dir = output_dir / "ORIGINAL_PDFs"
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(pdf_path), str(dest_dir / pdf_path.name))
        logger.info("Debug mode: copied PDF to output, kept in input folder: %s", pdf_path.name)
        dest_pdf = dest_dir / pdf_path.name
        for cmd in process_file_plugins:
            plugin_runner.run_plugin(cmd, {"<pdf>": str(dest_pdf)})
    else:
        output_handler.move_pdf(pdf_path, output_dir / "ORIGINAL_PDFs")
        logger.info("Finished PDF: %s", pdf_path.name)
        dest_pdf = output_dir / "ORIGINAL_PDFs" / pdf_path.name
        for cmd in process_file_plugins:
            plugin_runner.run_plugin(cmd, {"<pdf>": str(dest_pdf)})

    return not failed
