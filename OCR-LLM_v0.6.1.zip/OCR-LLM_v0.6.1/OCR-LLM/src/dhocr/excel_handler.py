import csv
import io
import logging
import re
from pathlib import Path

import openpyxl

logger = logging.getLogger(__name__)

_KEY_COL = "json_file"
_CSV_FENCE_RE = re.compile(r"^```(?:csv)?\n(.*)\n```$", re.DOTALL)


def _parse_csv_fenced(value: str) -> list[dict] | None:
    m = _CSV_FENCE_RE.match(value.strip())
    if not m:
        return None
    rows = [dict(r) for r in csv.DictReader(io.StringIO(m.group(1)))]
    return rows if rows else None


def _flatten_rows(data: dict) -> list[dict]:
    """Expand a list-of-dicts value into multiple flat row dicts.

    Fenced CSV strings (```csv\\n...\\n```) are first converted to list-of-dicts.
    If any value in *data* is a non-empty list of dicts, those dicts are
    expanded into individual rows with all other (scalar/list-of-scalar)
    fields merged into each row.  The first such key found is used.
    If no list-of-dicts value exists, returns [data] unchanged.
    """
    normalized = {
        k: (_parse_csv_fenced(v) or v) if isinstance(v, str) else v
        for k, v in data.items()
    }
    array_key = next(
        (k for k, v in normalized.items()
         if isinstance(v, list) and v and isinstance(v[0], dict)),
        None,
    )
    if array_key is None:
        return [normalized]
    base = {k: v for k, v in normalized.items() if k != array_key}
    return [{**base, **item} for item in normalized[array_key]]


def append_to_excel(data: dict, excel_path: str | Path, json_file: str | Path) -> None:
    """Write *data* as one or more rows to the Excel file at *excel_path*.

    If *data* contains a list-of-dicts value (e.g. a table extracted from a form),
    each dict in that list becomes its own row; other fields are repeated on every row.
    For flat data, a single row is written as before.

    Creates the file with a header row if it does not exist.
    Adds new columns for any keys not yet present (inserted before the key column).
    List-of-scalar values are serialised as comma-separated strings.
    "json_file" is always the last column and is the unique source key:
    all existing rows with the same json_file value are replaced.
    """
    excel_path = Path(excel_path)
    excel_path.parent.mkdir(parents=True, exist_ok=True)
    json_file_str = str(Path(json_file).resolve())

    def _cell_value(v) -> str:
        if isinstance(v, list):
            return ", ".join(str(item) for item in v)
        return str(v) if v is not None else ""

    # Expand array-of-objects into individual row dicts.
    rows_data = _flatten_rows(data)

    # Collect all unique keys across every expanded row (first-seen order).
    all_keys: list[str] = []
    seen_keys: set[str] = set()
    for row_data in rows_data:
        for k in row_data:
            if k not in seen_keys:
                all_keys.append(k)
                seen_keys.add(k)

    if excel_path.exists():
        wb = openpyxl.load_workbook(excel_path)
        ws = wb.active
        assert ws is not None
        headers = [cell.value for cell in ws[1]]

        if _KEY_COL in headers:
            key_pos = headers.index(_KEY_COL)  # 0-based
            new_keys = [k for k in all_keys if k not in headers]
            if new_keys:
                insert_col = key_pos + 1  # openpyxl uses 1-based column numbers
                ws.insert_cols(insert_col, len(new_keys))
                for i, key in enumerate(new_keys):
                    ws.cell(row=1, column=insert_col + i, value=key)
                headers = headers[:key_pos] + new_keys + headers[key_pos:]
        else:
            new_keys = [k for k in all_keys if k not in headers]
            for key in new_keys:
                headers.append(key)
                ws.cell(row=1, column=len(headers), value=key)
            headers.append(_KEY_COL)
            ws.cell(row=1, column=len(headers), value=_KEY_COL)
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        assert ws is not None
        headers = all_keys + [_KEY_COL]
        ws.append(headers)

    key_col_idx = len(headers)  # 1-based column index of json_file (_KEY_COL is always last)

    existing_rows = [
        r for r in range(2, (ws.max_row or 1) + 1)
        if ws.cell(row=r, column=key_col_idx).value == json_file_str
    ]
    n_existing = len(existing_rows)
    n_new = len(rows_data)

    if n_existing == 0:
        for row_data in rows_data:
            row = [_cell_value(row_data.get(h)) for h in headers[:-1]] + [json_file_str]
            ws.append(row)
        logger.info("Appended %d row(s) to Excel: %s", n_new, excel_path)
    else:
        # Update matching rows in-place.
        for i, row_data in enumerate(rows_data[:n_existing]):
            row_num = existing_rows[i]
            for col_idx, h in enumerate(headers[:-1], start=1):
                ws.cell(row=row_num, column=col_idx, value=_cell_value(row_data.get(h)))
            ws.cell(row=row_num, column=len(headers), value=json_file_str)

        if n_new < n_existing:
            for row_num in reversed(existing_rows[n_new:]):
                ws.delete_rows(row_num)
        elif n_new > n_existing:
            insert_after = existing_rows[-1]
            for i, row_data in enumerate(rows_data[n_existing:], start=1):
                insert_at = insert_after + i
                ws.insert_rows(insert_at)
                row = [_cell_value(row_data.get(h)) for h in headers[:-1]] + [json_file_str]
                for col_idx, val in enumerate(row, start=1):
                    ws.cell(row=insert_at, column=col_idx, value=val)

        logger.info("Updated %d row(s) in-place in Excel: %s", n_new, excel_path)

    wb.save(excel_path)
