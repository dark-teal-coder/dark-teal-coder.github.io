import logging
import shlex
import subprocess
import sys

logger = logging.getLogger(__name__)


def run_plugin(command_template: str, placeholders: dict[str, str]) -> None:
    """Run a plugin command, substituting placeholders with actual values.

    Splits the template into tokens first, then substitutes each token so
    that path values containing spaces remain single arguments. If the first
    token ends with '.py', it is invoked via sys.executable. Failures are
    logged but never raised.
    """
    try:
        tokens = shlex.split(command_template)
    except ValueError as exc:
        logger.error("Plugin command template parse error: %s — %s", command_template, exc)
        return

    args = []
    for token in tokens:
        for placeholder, value in placeholders.items():
            token = token.replace(placeholder, value)
        args.append(token)

    if args and args[0].endswith(".py"):
        args = [sys.executable] + args

    try:
        result = subprocess.run(args, capture_output=True, text=True)
        if result.returncode != 0:
            logger.warning(
                "Plugin exited with code %d: %s\nstdout: %s\nstderr: %s",
                result.returncode, " ".join(args), result.stdout.strip(), result.stderr.strip(),
            )
        else:
            logger.info("Plugin completed: %s", " ".join(args))
    except Exception as exc:
        logger.error("Plugin failed to run: %s — %s", " ".join(args), exc)
