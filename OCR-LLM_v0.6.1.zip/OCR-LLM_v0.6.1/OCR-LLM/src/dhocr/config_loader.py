import json
from pathlib import Path


def load_global_config(path: str | Path) -> dict:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Global config not found: {path}")
    with open(path, encoding="utf-8") as f:
        config = json.load(f)
    for key in ("forms_config_dir", "llm"):
        if key not in config:
            raise ValueError(f"Global config missing required key: '{key}'")

    pairs = [
        ("forms_input_folder", "forms_output_folder"),
        ("forms_qr_input_folder", "forms_qr_output_folder"),
        ("forms_mixed_input_folder", "forms_mixed_output_folder"),
    ]
    valid_pairs = []
    for in_key, out_key in pairs:
        has_in = in_key in config
        has_out = out_key in config
        if has_in != has_out:
            missing = out_key if has_in else in_key
            raise ValueError(f"Global config: '{missing}' must be defined when its pair is present")
        if has_in and has_out:
            valid_pairs.append((in_key, out_key))

    if not valid_pairs:
        raise ValueError(
            "Global config must define at least one input/output folder pair "
            "('forms_input_folder'/'forms_output_folder' or "
            "'forms_qr_input_folder'/'forms_qr_output_folder')"
        )
    for key in ("endpoint", "model", "api_key"):
        if key not in config["llm"]:
            raise ValueError(f"Global config llm section missing required key: '{key}'")
    return config


def get_form_config(form_id: str | None, forms_dir: str | Path) -> dict:
    forms_dir = Path(forms_dir)
    if form_id:
        candidate = forms_dir / f"{form_id}.json"
        if candidate.exists():
            with open(candidate, encoding="utf-8") as f:
                return json.load(f)

    raise FileNotFoundError(
        f"No form config found for form_id='{form_id}' in {forms_dir}"
    )
