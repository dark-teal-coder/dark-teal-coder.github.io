import json
import logging
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)


def merge_jsons(page_results: list[dict]) -> dict:
    """Merge a list of per-page JSON dicts into a single flat dict.

    When the same key appears on multiple pages, the values are combined
    into a list (existing scalar values are promoted to a list on first conflict).
    """
    merged: dict = {}
    for page_data in page_results:
        for key, value in page_data.items():
            if key not in merged:
                merged[key] = value
            else:
                existing = merged[key]
                if isinstance(existing, list):
                    if isinstance(value, list):
                        existing.extend(value)
                    else:
                        existing.append(value)
                else:
                    if isinstance(value, list):
                        merged[key] = [existing, *value]
                    else:
                        merged[key] = [existing, value]
    return merged


def write_json(data: dict, output_path: str | Path) -> None:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    logger.info("Wrote JSON: %s", output_path)


def move_pdf(pdf_path: str | Path, dest_dir: str | Path) -> Path:
    """Move *pdf_path* to *dest_dir*, returning the new path."""
    pdf_path = Path(pdf_path)
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / pdf_path.name
    shutil.move(str(pdf_path), str(dest))
    logger.info("Moved PDF: %s → %s", pdf_path, dest)
    return dest
