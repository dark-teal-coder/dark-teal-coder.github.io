import json
import logging
from pathlib import Path

import zxingcpp
from PIL import Image

logger = logging.getLogger(__name__)


def decode_qr(image_path: str | Path) -> dict | None:
    """Decode the first QR code found in the image.

    Expected QR payload: JSON string with at least "form_id" and "page" keys,
    e.g. {"form_id": "F001", "page": 1}

    Returns the parsed dict, or None if no valid QR code is found.
    Raises ValueError if a QR code is found but its payload is invalid.
    """
    image_path = Path(image_path)
    try:
        img = Image.open(image_path)
    except Exception as exc:
        logger.warning("Could not open image %s: %s", image_path, exc)
        return None

    results = zxingcpp.read_barcodes(img)
    for result in results:
        if result.format != zxingcpp.BarcodeFormat.QRCode:
            continue
        raw = result.text.strip()
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            raise ValueError(
                f"QR code on {image_path.name} is not valid JSON: {raw!r}"
            )
        if "form_id" not in data or "page" not in data:
            raise ValueError(
                f"QR code on {image_path.name} missing 'form_id' or 'page' keys: {data}"
            )
        return data

    return None
