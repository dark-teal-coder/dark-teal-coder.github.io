"""Test plugin: fires after a JSON record is updated via the Review app."""
import argparse
import json
from datetime import datetime
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("-i", "--input", required=True, help="Path to the JSON output file")
args = parser.parse_args()

json_path = Path(args.input)
log_path = Path(__file__).parent / "plugin_test.log"

with open(log_path, "a", encoding="utf-8") as log:
    entry = {
        "hook": "update_record",
        "timestamp": datetime.now().isoformat(),
        "json_file": str(json_path),
        "json_exists": json_path.exists(),
    }
    if json_path.exists():
        with open(json_path, encoding="utf-8") as f:
            data = json.load(f)
        entry["field_count"] = len(data)
    log.write(json.dumps(entry, ensure_ascii=False) + "\n")

print(f"[update_record] logged: {json_path}")
