"""Test plugin: fires after a PDF has finished processing and been moved to ORIGINAL_PDFs."""
import argparse
import json
from datetime import datetime
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("-i", "--input", required=True, help="Path to the processed PDF file")
args = parser.parse_args()

pdf_path = Path(args.input)
log_path = Path(__file__).parent / "plugin_test.log"

with open(log_path, "a", encoding="utf-8") as log:
    entry = {
        "hook": "process_file",
        "timestamp": datetime.now().isoformat(),
        "pdf_file": str(pdf_path),
        "pdf_exists": pdf_path.exists(),
        "pdf_size_bytes": pdf_path.stat().st_size if pdf_path.exists() else None,
    }
    log.write(json.dumps(entry, ensure_ascii=False) + "\n")

print(f"[process_file] logged: {pdf_path}")
