import sys
import json

if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} <input_file>", file=sys.stderr)
    sys.exit(1)

with open(sys.argv[1], "r", encoding="utf-8") as f:
    content = f.read()

print(json.dumps(content))
