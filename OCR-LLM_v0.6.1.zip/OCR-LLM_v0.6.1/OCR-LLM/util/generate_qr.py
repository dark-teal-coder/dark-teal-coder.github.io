#!/usr/bin/env python3
"""Generate a QR code PNG image from a command line text input."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate a PNG QR code image from a text string."
    )
    parser.add_argument(
        "text",
        nargs="+",
        help="Text to encode into the QR code. Use quotes for multi-word text.",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="qrcode.png",
        help="Output PNG file path (default: qrcode.png).",
    )
    parser.add_argument(
        "--scale",
        type=int,
        default=10,
        help="Box size for each QR module (default: 10).",
    )
    parser.add_argument(
        "--border",
        type=int,
        default=4,
        help="Border width around the QR code in boxes (default: 4).",
    )
    return parser.parse_args()


def generate_qr(text: str, output_path: Path, scale: int = 10, border: int = 4) -> Path:
    try:
        import qrcode
    except ImportError as exc:
        raise RuntimeError(
            "The qrcode package is required. Install it with: pip install qrcode[pil]"
        ) from exc

    qr = qrcode.QRCode(
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=scale,
        border=border,
    )
    qr.add_data(text)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(output_path, format="PNG")
    return output_path


def main() -> int:
    args = parse_args()
    text = " ".join(args.text)
    output_path = Path(args.output)

    try:
        saved_path = generate_qr(text, output_path, scale=args.scale, border=args.border)
        print(f"QR code saved to: {saved_path}")
        return 0
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
