"""
compare_excel.py — Cell-by-cell comparison of two Excel files.

Usage:
    python3 compare_excel.py <file1.xlsx> <file2.xlsx> [output.xlsx]

If output path is omitted, the report is saved next to file1 as
<file1_basename>_Comparison.xlsx.
"""

import os
import sys
from openpyxl import load_workbook, Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side


def compare_excel(f1_path, f2_path, out_path):
    wb1 = load_workbook(f1_path, data_only=True)
    wb2 = load_workbook(f2_path, data_only=True)
    ws1 = wb1[wb1.sheetnames[0]]
    ws2 = wb2[wb2.sheetnames[0]]

    red_fill    = PatternFill("solid", start_color="FFCCCC", fgColor="FFCCCC")
    green_fill  = PatternFill("solid", start_color="C6EFCE", fgColor="C6EFCE")
    header_fill = PatternFill("solid", start_color="4472C4", fgColor="4472C4")
    header_font = Font(bold=True, color="FFFFFF", name="Arial")
    normal_font = Font(name="Arial", size=10)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    left   = Alignment(horizontal="left",   vertical="center", wrap_text=True)
    thin   = Side(style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    f1_rows = list(ws1.iter_rows(min_row=2, values_only=True))
    f2_rows = list(ws2.iter_rows(min_row=2, values_only=True))
    col_labels = ["Name", "Sex", "Age", "E Cause", "CCMA / Order No."]

    f1_name = os.path.basename(f1_path)
    f2_name = os.path.basename(f2_path)

    wb_out = Workbook()

    # --- Differences sheet ---
    ws_diff = wb_out.active
    ws_diff.title = "Differences"
    for c, h in enumerate(["Row", "Field", f"File 1 ({f1_name})", f"File 2 ({f2_name})", "Match?"], 1):
        cell = ws_diff.cell(row=1, column=c, value=h)
        cell.fill = header_fill; cell.font = header_font
        cell.alignment = center; cell.border = border

    diff_row = 2
    total_cells = match_count = diff_count = 0

    for i, (r1, r2) in enumerate(zip(f1_rows, f2_rows), start=2):
        pairs = list(zip(col_labels, r1[:5], r2[:5]))
        for field, v1, v2 in pairs:
            total_cells += 1
            v1s = str(v1).strip() if v1 is not None else ""
            v2s = str(v2).strip() if v2 is not None else ""
            match = v1s == v2s
            if match:
                match_count += 1
            else:
                diff_count += 1
                for c, val in enumerate([i - 1, field, v1s, v2s, "DIFF"], 1):
                    cell = ws_diff.cell(row=diff_row, column=c, value=val)
                    cell.font = normal_font; cell.border = border
                    cell.alignment = left if c > 1 else center
                    if c == 5:
                        cell.fill = red_fill
                        cell.font = Font(bold=True, color="CC0000", name="Arial")
                    elif c in (3, 4):
                        cell.fill = red_fill
                diff_row += 1

    for col, w in zip("ABCDE", [6, 20, 55, 55, 10]):
        ws_diff.column_dimensions[col].width = w

    # --- All Rows sheet ---
    ws_all = wb_out.create_sheet("All Rows")
    for c, h in enumerate(["Row", "Field", f"File 1 ({f1_name})", f"File 2 ({f2_name})", "Match?"], 1):
        cell = ws_all.cell(row=1, column=c, value=h)
        cell.fill = header_fill; cell.font = header_font
        cell.alignment = center; cell.border = border

    all_row = 2
    for i, (r1, r2) in enumerate(zip(f1_rows, f2_rows), start=2):
        pairs = list(zip(col_labels, r1[:5], r2[:5]))
        for field, v1, v2 in pairs:
            v1s = str(v1).strip() if v1 is not None else ""
            v2s = str(v2).strip() if v2 is not None else ""
            match = v1s == v2s
            for c, val in enumerate([i - 1, field, v1s, v2s, "MATCH" if match else "DIFF"], 1):
                cell = ws_all.cell(row=all_row, column=c, value=val)
                cell.font = normal_font; cell.border = border
                cell.alignment = left if c > 1 else center
                if c == 5:
                    if match:
                        cell.fill = green_fill
                        cell.font = Font(bold=True, color="375623", name="Arial")
                    else:
                        cell.fill = red_fill
                        cell.font = Font(bold=True, color="CC0000", name="Arial")
                elif c in (3, 4) and not match:
                    cell.fill = red_fill
            all_row += 1

    for col, w in zip("ABCDE", [6, 20, 55, 55, 10]):
        ws_all.column_dimensions[col].width = w

    # --- Summary sheet ---
    ws_sum = wb_out.create_sheet("Summary", 0)
    ws_sum.column_dimensions["A"].width = 30
    ws_sum.column_dimensions["B"].width = 20
    summary_data = [
        ("Comparison Summary", None),
        (None, None),
        ("File 1", f1_path),
        ("File 2", f2_path),
        ("Fields Compared", ", ".join(col_labels)),
        ("Total Rows Compared", len(f1_rows)),
        ("Total Cells Compared", total_cells),
        ("Matching Cells", match_count),
        ("Different Cells", diff_count),
        ("Match Rate", f"{match_count / total_cells * 100:.1f}%"),
    ]
    for r_idx, (label, value) in enumerate(summary_data, 1):
        if label:
            ca = ws_sum.cell(row=r_idx, column=1, value=label)
            ca.font = Font(bold=True, name="Arial", size=11 if r_idx == 1 else 10)
            ca.alignment = left
            if r_idx == 1:
                ca.fill = header_fill
                ca.font = Font(bold=True, color="FFFFFF", name="Arial", size=13)
        if value is not None:
            ws_sum.cell(row=r_idx, column=2, value=value).font = Font(name="Arial", size=10)

    wb_out.save(out_path)
    print(f"Saved: {out_path}")
    print(f"{total_cells} cells compared: {match_count} match, {diff_count} differ "
          f"({match_count / total_cells * 100:.1f}% match rate)")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 compare_excel.py <file1.xlsx> <file2.xlsx> [output.xlsx]")
        sys.exit(1)

    f1 = sys.argv[1]
    f2 = sys.argv[2]

    if len(sys.argv) >= 4:
        out = sys.argv[3]
    else:
        base = os.path.splitext(os.path.basename(f1))[0]
        out = os.path.join(os.path.dirname(f1), f"{base}_Comparison.xlsx")

    compare_excel(f1, f2, out)
