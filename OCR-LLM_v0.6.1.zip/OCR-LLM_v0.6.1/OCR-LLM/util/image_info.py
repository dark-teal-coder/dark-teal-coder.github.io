#!/usr/bin/env python3
"""
Script to print image dimensions and color/grayscale attribute.
Supports PNG, JPEG, and TIF/TIFF formats.

Usage:
    python image_info.py <image_path>
"""

import sys
from pathlib import Path
from PIL import Image


def get_image_info(image_path):
    """
    Get image dimensions and color mode.
    
    Args:
        image_path: Path to the image file (PNG or JPEG)
        
    Returns:
        dict: Contains 'width', 'height', and 'color_mode'
    """
    try:
        img = Image.open(image_path)
        width, height = img.size
        
        # Determine if image is grayscale or color
        if img.mode in ('L', 'LA'):
            color_mode = 'Grayscale'
        elif img.mode in ('RGB', 'RGBA', 'CMYK'):
            color_mode = 'Color'
        else:
            color_mode = f'Unknown ({img.mode})'
        
        return {
            'width': width,
            'height': height,
            'mode': img.mode,
            'color_mode': color_mode,
            'format': img.format
        }
    except FileNotFoundError:
        print(f"Error: File not found: {image_path}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: Unable to open image: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    if len(sys.argv) < 2:
        print("Usage: python image_info.py <image_path>", file=sys.stderr)
        print("Supported formats: PNG, JPEG, TIF, TIFF", file=sys.stderr)
        sys.exit(1)
    
    image_path = sys.argv[1]
    
    # Validate file extension
    valid_extensions = {'.png', '.jpg', '.jpeg', '.tif', '.tiff'}
    if Path(image_path).suffix.lower() not in valid_extensions:
        print(f"Error: Unsupported file format. Supported: PNG, JPEG, TIF, TIFF", file=sys.stderr)
        sys.exit(1)
    
    info = get_image_info(image_path)
    
    print(f"Image: {Path(image_path).name}")
    print(f"Dimensions: {info['width']} x {info['height']} pixels")
    print(f"Color Mode: {info['color_mode']} ({info['mode']})")
    print(f"Format: {info['format']}")


if __name__ == '__main__':
    main()
